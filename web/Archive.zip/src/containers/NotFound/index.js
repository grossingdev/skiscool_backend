require('./styles.scss');

import React, { Component } from 'react';

class NotFound extends Component {
  render() {
    return (
      <div className="NotFound">
        Page Not Found
      </div>
    );
  }
}

export default NotFound;
