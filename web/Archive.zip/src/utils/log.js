/**
 * Created by nick on 4/16/16.
 */

const logConsole = (log) => {
  console.info(log);
};

export default logConsole;